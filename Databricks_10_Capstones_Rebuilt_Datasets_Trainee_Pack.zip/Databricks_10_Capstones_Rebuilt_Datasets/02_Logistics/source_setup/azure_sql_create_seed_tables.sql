-- Azure SQL seed destination: carrier_master
IF OBJECT_ID('dbo.carrier_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.carrier_master (
    [carrier_id] NVARCHAR(255) NULL,
    [carrier_name] NVARCHAR(255) NULL,
    [service_region] NVARCHAR(255) NULL,
    [carrier_tier] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [onboarded_date] NVARCHAR(255) NULL,
    [contract_type] NVARCHAR(255) NULL,
    [service_level] NVARCHAR(255) NULL,
    [country] NVARCHAR(255) NULL,
    [support_group] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: warehouse_master
IF OBJECT_ID('dbo.warehouse_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.warehouse_master (
    [warehouse_id] NVARCHAR(255) NULL,
    [warehouse_name] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [region] NVARCHAR(255) NULL,
    [country] NVARCHAR(255) NULL,
    [capacity_units] NVARCHAR(255) NULL,
    [warehouse_type] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [opening_date] NVARCHAR(255) NULL,
    [manager_code] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: route_master
IF OBJECT_ID('dbo.route_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.route_master (
    [route_id] NVARCHAR(255) NULL,
    [origin_warehouse_id] NVARCHAR(255) NULL,
    [destination_city] NVARCHAR(255) NULL,
    [distance_km] NVARCHAR(255) NULL,
    [route_class] NVARCHAR(255) NULL,
    [planned_hours] NVARCHAR(255) NULL,
    [service_region] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [vehicle_class] NVARCHAR(255) NULL,
    [route_owner] NVARCHAR(255) NULL
  );
END;
GO
