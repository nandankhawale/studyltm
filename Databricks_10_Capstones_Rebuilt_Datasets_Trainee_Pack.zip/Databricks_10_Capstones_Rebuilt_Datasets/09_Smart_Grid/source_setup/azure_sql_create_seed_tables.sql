-- Azure SQL seed destination: meter_master
IF OBJECT_ID('dbo.meter_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.meter_master (
    [meter_id] NVARCHAR(255) NULL,
    [substation_id] NVARCHAR(255) NULL,
    [meter_type] NVARCHAR(255) NULL,
    [installation_date] NVARCHAR(255) NULL,
    [service_region] NVARCHAR(255) NULL,
    [meter_status] NVARCHAR(255) NULL,
    [customer_class] NVARCHAR(255) NULL,
    [rated_voltage] NVARCHAR(255) NULL,
    [manufacturer] NVARCHAR(255) NULL,
    [tariff_code] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: substation_master
IF OBJECT_ID('dbo.substation_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.substation_master (
    [substation_id] NVARCHAR(255) NULL,
    [substation_name] NVARCHAR(255) NULL,
    [region] NVARCHAR(255) NULL,
    [capacity_mva] NVARCHAR(255) NULL,
    [voltage_level_kv] NVARCHAR(255) NULL,
    [commissioned_date] NVARCHAR(255) NULL,
    [operator] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [latitude] NVARCHAR(255) NULL,
    [longitude] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: tariff_lookup
IF OBJECT_ID('dbo.tariff_lookup', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.tariff_lookup (
    [tariff_code] NVARCHAR(255) NULL,
    [tariff_name] NVARCHAR(255) NULL,
    [customer_class] NVARCHAR(255) NULL,
    [rate_per_kwh] NVARCHAR(255) NULL,
    [effective_date] NVARCHAR(255) NULL,
    [expiry_date] NVARCHAR(255) NULL,
    [currency] NVARCHAR(255) NULL,
    [peak_multiplier] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [regulatory_zone] NVARCHAR(255) NULL
  );
END;
GO
