-- Azure SQL seed destination: machine_master
IF OBJECT_ID('dbo.machine_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.machine_master (
    [machine_id] NVARCHAR(255) NULL,
    [plant_id] NVARCHAR(255) NULL,
    [machine_type] NVARCHAR(255) NULL,
    [manufacturer] NVARCHAR(255) NULL,
    [commissioned_date] NVARCHAR(255) NULL,
    [criticality] NVARCHAR(255) NULL,
    [rated_rpm] NVARCHAR(255) NULL,
    [operating_status] NVARCHAR(255) NULL,
    [maintenance_interval_days] NVARCHAR(255) NULL,
    [line_id] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: plant_master
IF OBJECT_ID('dbo.plant_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.plant_master (
    [plant_id] NVARCHAR(255) NULL,
    [plant_name] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [region] NVARCHAR(255) NULL,
    [country] NVARCHAR(255) NULL,
    [plant_type] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [production_line_count] NVARCHAR(255) NULL,
    [timezone] NVARCHAR(255) NULL,
    [plant_manager] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: failure_code_lookup
IF OBJECT_ID('dbo.failure_code_lookup', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.failure_code_lookup (
    [failure_code] NVARCHAR(255) NULL,
    [failure_category] NVARCHAR(255) NULL,
    [failure_description] NVARCHAR(255) NULL,
    [severity_default] NVARCHAR(255) NULL,
    [action_required] NVARCHAR(255) NULL,
    [root_cause_group] NVARCHAR(255) NULL,
    [reportable_flag] NVARCHAR(255) NULL,
    [asset_class] NVARCHAR(255) NULL,
    [owner_team] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL
  );
END;
GO
