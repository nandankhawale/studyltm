-- Azure SQL seed destination: policy_master
IF OBJECT_ID('dbo.policy_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.policy_master (
    [policy_id] NVARCHAR(255) NULL,
    [customer_id] NVARCHAR(255) NULL,
    [coverage_code] NVARCHAR(255) NULL,
    [policy_start_date] NVARCHAR(255) NULL,
    [policy_end_date] NVARCHAR(255) NULL,
    [premium_amount] NVARCHAR(255) NULL,
    [sum_insured] NVARCHAR(255) NULL,
    [policy_status] NVARCHAR(255) NULL,
    [effective_from] NVARCHAR(255) NULL,
    [effective_to] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: customer_master
IF OBJECT_ID('dbo.customer_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.customer_master (
    [customer_id] NVARCHAR(255) NULL,
    [customer_segment] NVARCHAR(255) NULL,
    [home_region] NVARCHAR(255) NULL,
    [onboarded_date] NVARCHAR(255) NULL,
    [risk_band] NVARCHAR(255) NULL,
    [customer_status] NVARCHAR(255) NULL,
    [kyc_status] NVARCHAR(255) NULL,
    [customer_type] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [account_manager] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: coverage_lookup
IF OBJECT_ID('dbo.coverage_lookup', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.coverage_lookup (
    [coverage_code] NVARCHAR(255) NULL,
    [coverage_name] NVARCHAR(255) NULL,
    [coverage_group] NVARCHAR(255) NULL,
    [max_limit] NVARCHAR(255) NULL,
    [deductible] NVARCHAR(255) NULL,
    [currency] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [effective_date] NVARCHAR(255) NULL,
    [exclusion_group] NVARCHAR(255) NULL,
    [underwriter] NVARCHAR(255) NULL
  );
END;
GO
