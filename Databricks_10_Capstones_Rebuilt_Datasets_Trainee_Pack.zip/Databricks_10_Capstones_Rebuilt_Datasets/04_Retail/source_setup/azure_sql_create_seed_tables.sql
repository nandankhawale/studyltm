-- Azure SQL seed destination: product_master
IF OBJECT_ID('dbo.product_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.product_master (
    [product_id] NVARCHAR(255) NULL,
    [sku] NVARCHAR(255) NULL,
    [product_name] NVARCHAR(255) NULL,
    [category] NVARCHAR(255) NULL,
    [subcategory] NVARCHAR(255) NULL,
    [unit_of_measure] NVARCHAR(255) NULL,
    [list_price] NVARCHAR(255) NULL,
    [cost_price] NVARCHAR(255) NULL,
    [supplier_id] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: store_master
IF OBJECT_ID('dbo.store_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.store_master (
    [store_id] NVARCHAR(255) NULL,
    [store_name] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [region] NVARCHAR(255) NULL,
    [store_type] NVARCHAR(255) NULL,
    [opening_date] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [warehouse_id] NVARCHAR(255) NULL,
    [manager_code] NVARCHAR(255) NULL,
    [country] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: supplier_master
IF OBJECT_ID('dbo.supplier_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.supplier_master (
    [supplier_id] NVARCHAR(255) NULL,
    [supplier_name] NVARCHAR(255) NULL,
    [country] NVARCHAR(255) NULL,
    [lead_time_days] NVARCHAR(255) NULL,
    [payment_terms] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [supplier_tier] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [category] NVARCHAR(255) NULL,
    [contact_code] NVARCHAR(255) NULL
  );
END;
GO
