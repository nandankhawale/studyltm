-- Azure SQL seed destination: airport_master
IF OBJECT_ID('dbo.airport_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.airport_master (
    [airport_id] NVARCHAR(255) NULL,
    [airport_name] NVARCHAR(255) NULL,
    [iata_code] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [country] NVARCHAR(255) NULL,
    [timezone] NVARCHAR(255) NULL,
    [latitude] NVARCHAR(255) NULL,
    [longitude] NVARCHAR(255) NULL,
    [airport_class] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: airline_master
IF OBJECT_ID('dbo.airline_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.airline_master (
    [airline_id] NVARCHAR(255) NULL,
    [airline_name] NVARCHAR(255) NULL,
    [iata_code] NVARCHAR(255) NULL,
    [home_country] NVARCHAR(255) NULL,
    [operating_region] NVARCHAR(255) NULL,
    [carrier_type] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [alliance] NVARCHAR(255) NULL,
    [fleet_size] NVARCHAR(255) NULL,
    [onboarded_date] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: aircraft_master
IF OBJECT_ID('dbo.aircraft_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.aircraft_master (
    [aircraft_id] NVARCHAR(255) NULL,
    [aircraft_type] NVARCHAR(255) NULL,
    [manufacturer] NVARCHAR(255) NULL,
    [seat_capacity] NVARCHAR(255) NULL,
    [airline_id] NVARCHAR(255) NULL,
    [manufacture_year] NVARCHAR(255) NULL,
    [fleet_status] NVARCHAR(255) NULL,
    [range_km] NVARCHAR(255) NULL,
    [engine_type] NVARCHAR(255) NULL,
    [maintenance_base] NVARCHAR(255) NULL
  );
END;
GO
