-- Azure SQL seed destination: user_master
IF OBJECT_ID('dbo.user_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.user_master (
    [user_id] NVARCHAR(255) NULL,
    [department] NVARCHAR(255) NULL,
    [role_code] NVARCHAR(255) NULL,
    [employment_status] NVARCHAR(255) NULL,
    [join_date] NVARCHAR(255) NULL,
    [location] NVARCHAR(255) NULL,
    [manager_id] NVARCHAR(255) NULL,
    [data_access_tier] NVARCHAR(255) NULL,
    [business_unit] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: document_category_lookup
IF OBJECT_ID('dbo.document_category_lookup', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.document_category_lookup (
    [category_code] NVARCHAR(255) NULL,
    [category_name] NVARCHAR(255) NULL,
    [retention_class] NVARCHAR(255) NULL,
    [default_classification] NVARCHAR(255) NULL,
    [owner_team] NVARCHAR(255) NULL,
    [is_searchable] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [retention_years] NVARCHAR(255) NULL,
    [content_type] NVARCHAR(255) NULL,
    [review_frequency] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: role_permission_lookup
IF OBJECT_ID('dbo.role_permission_lookup', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.role_permission_lookup (
    [role_code] NVARCHAR(255) NULL,
    [resource_classification] NVARCHAR(255) NULL,
    [permission_level] NVARCHAR(255) NULL,
    [allowed_action] NVARCHAR(255) NULL,
    [approval_required] NVARCHAR(255) NULL,
    [effective_date] NVARCHAR(255) NULL,
    [expiry_date] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [policy_owner] NVARCHAR(255) NULL,
    [policy_version] NVARCHAR(255) NULL
  );
END;
GO
