CREATE TABLE dbo.airline_id (airline_id VARCHAR(40) NOT NULL PRIMARY KEY, display_name VARCHAR(100), region VARCHAR(20), active_flag CHAR(1), effective_date DATE, risk_tier VARCHAR(10));
-- Import datasets/azure_sql_extracts/airline_id.csv into dbo.airline_id using Azure SQL import tools or an approved ingestion process.
CREATE TABLE dbo.airport_id (airport_id VARCHAR(40) NOT NULL PRIMARY KEY, display_name VARCHAR(100), region VARCHAR(20), active_flag CHAR(1), effective_date DATE, risk_tier VARCHAR(10));
-- Import datasets/azure_sql_extracts/airport_id.csv into dbo.airport_id using Azure SQL import tools or an approved ingestion process.
